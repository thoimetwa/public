package upwork.quiz;

public class SinglyLinkedList {
	private Node head;

	public boolean isEmpty() {
		return length() == 0;
	}

	public void append(int data) {
		if (head == null) {
			head = new Node(data);
			return;
		}
		tail().next = new Node(data);
	}
	
	public boolean remove(int index) {
		 
		// if the index is out of range, exit
		if (index >= length())
			return false;
		
		if (index == 0) {
			head = head.next;
			return true;
		}
 
		Node current = head;
		if (head != null) {
			for (int i = 1; i < index; i++) {
				if (current.next == null)
					return false;
				current = current.next;
			}
			current.next = current.next.next;
			return true;
 
		}
		return false;
	}
	
	public boolean removeTail() {
		return remove(length() - 1);
	}
	
	public boolean removeNodeGreater(int targetValue) {
		boolean result = true;
		int index = 0;
		Node current = head;
		while (current != null) {
			if (current.getData() > targetValue) {
				result = result && remove(index);
				index = 0;
				current = head;
			} else {
				current = current.next;
				index++;
			}
		}
		return result;
	}

	private Node tail() {
		Node tail = head;
		// Find last element of linked list known as tail
		while (tail.next != null) {
			tail = tail.next;
		}
		return tail;
	}

	@Override
	public String toString() {
		String output = "";
		Node current = head;
		while (current != null) {
			output += "[" + current.getData() + "]";
			current = current.next;
		}
		
		return output;
	}

	public int length() {
		int length = 0;
		Node current = head; // Starts counting from head - first node
		while (current != null) {
			length++;
			current = current.next;
		}
		return length;
	}

	// Node is nested static class because it only exists along with linked list
	// Node is private because it's implementation detail, and should not be exposed
	private static class Node {
		private Node next;
		private int data;

		public Node(int data) {
			this.data = data;
		}
		
		public int getData() {
			return this.data;
		}

		@Override
		public String toString() {
			return String.valueOf(this.data);
		}
	}

}