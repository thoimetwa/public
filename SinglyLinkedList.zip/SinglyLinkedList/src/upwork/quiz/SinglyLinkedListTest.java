package upwork.quiz;

public class SinglyLinkedListTest {
	public static SinglyLinkedList linkedList;

	public static void main(String[] args) {
		linkedList = new SinglyLinkedList();

		// add more elements to LinkedList
		linkedList.append(1);
		linkedList.append(2);
		linkedList.append(3);
		linkedList.append(4);
		linkedList.append(5);
		linkedList.append(6);
		linkedList.append(7);

		System.out.println("Print: linkedList: \t\t" + linkedList);
		System.out.println("Print: length: \t\t" + linkedList.length() + "\n");
		
		System.out.println("Print: remove head: \t\t" + linkedList.remove(0));
		System.out.println("Print: linkedList: \t\t" + linkedList);
		System.out.println("Print: length: \t\t" + linkedList.length() + "\n");
		
		System.out.println("Print: remove tail: \t\t" + linkedList.removeTail());
		System.out.println("Print: linkedList: \t\t" + linkedList);
		System.out.println("Print: length: \t\t" + linkedList.length() + "\n");
		
		
		System.out.println("Print: removeNodeGreater(3): \t\t" + linkedList.removeNodeGreater(3));
		System.out.println("Print: linkedList: \t\t" + linkedList);
		System.out.println("Print: length: \t\t" + linkedList.length() + "\n");
		

	}

}
